<?php

namespace Orchestra\Testbench\Traits;

/**
 * @deprecated v3.4.x
 */
trait ApplicationTrait
{
    use CreatesApplication;
}

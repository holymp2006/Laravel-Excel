<?php

namespace Orchestra\Testbench\Exceptions;

/**
 * @deprecated v3.3.0
 */
class ApplicationHandler extends Handler
{
    //
}

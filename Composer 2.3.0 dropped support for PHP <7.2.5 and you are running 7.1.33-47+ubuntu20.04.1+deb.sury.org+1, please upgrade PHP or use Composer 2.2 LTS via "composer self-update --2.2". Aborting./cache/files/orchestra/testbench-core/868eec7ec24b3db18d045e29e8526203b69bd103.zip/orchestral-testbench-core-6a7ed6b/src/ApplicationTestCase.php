<?php

namespace Orchestra\Testbench;

/**
 * @deprecated v3.3.0
 */
class ApplicationTestCase extends TestCase
{
    //
}
